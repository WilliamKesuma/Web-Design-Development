// Function to add todo
var listCount = 1;

function addTodo() {
    // Get the input value
    var todoText = document.getElementById("input-todo").value;

    // If input value is not empty
    if (todoText.trim() !== "") {
        // Create a new list item
        var newItem = document.createElement("li");
        newItem.className = "list-group-item";

        // Set the todo text
        newItem.innerHTML = '<span>' + todoText + '</span><button class="btn-danger" onclick="deleteTodo(' + ++listCount + ')">X</button>';

        // Append the new list item to the todo list
        document.getElementById("todo-list").appendChild(newItem);

        // Clear the input field
        document.getElementById("input-todo").value = "";

        // Add event listeners for hover effect
        newItem.addEventListener('mouseover', hoverEffect);
        newItem.addEventListener('mouseout', removeHoverEffect);
    }
}

// Function to handle hover effect
function hoverEffect() {
    this.style.backgroundColor = 'skyblue';
    this.style.color = 'white';
    this.style.borderColor = 'black';
}

// Function to remove hover effect
function removeHoverEffect() {
    this.style.backgroundColor = '';
    this.style.color = '';
    this.style.borderColor = '';
}

// Add event listeners for hover effect to existing todo items
var todoItems = document.querySelectorAll('.list-group-item');
todoItems.forEach(function (item) {
    item.addEventListener('mouseover', hoverEffect);
    item.addEventListener('mouseout', removeHoverEffect);
});

// Function to delete todo
function deleteTodo(index) {
    // Get the parent element (li) of the button clicked
    var listItem = document.getElementsByTagName("li")[index - 1];
    listItem.style.display = "none";
}
